package com.sanchezdarcypencuejesus.proyectofinal;


public interface iTrabajable {
    public String ejecutarTrabajo(); 
}
