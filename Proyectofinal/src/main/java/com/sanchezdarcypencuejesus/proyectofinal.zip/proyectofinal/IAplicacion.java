
package com.sanchezdarcypencuejesus.proyectofinal;


public interface IAplicacion {
    public String abrirApp();
    public String actualizarApp();
    public String EliminarApp();
}
